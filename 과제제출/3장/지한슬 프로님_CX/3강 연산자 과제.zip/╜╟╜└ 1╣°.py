import math
a = 21.9; b = 37; c = 13.6;
average = math.trunc((a+b+c)/3);
print ("average = ",average);
